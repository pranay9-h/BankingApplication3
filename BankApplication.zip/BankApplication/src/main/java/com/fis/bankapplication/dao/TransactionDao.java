 package com.fis.bankapplication.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.model.Transaction;

@Repository
public interface TransactionDao extends CrudRepository<Transaction,Long> {
	
//	   public abstract String addTransaction(Transaction transaction);
//	   
//	   public abstract List<Transaction> getAllTransactions();
//	   
	@Query("select t from Transaction t where t.fromAcc =?1 OR t.toAcc = ?1") // Sql Query for getting all transactions by account number 
	   public List<Transaction> getAllTransactionsByAccno(long accNum);

}
