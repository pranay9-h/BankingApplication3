package com.fis.bankapplication.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.model.Customer;

@Repository
public interface CustomerDao extends CrudRepository<Customer, Integer>  {
//
//    public abstract String addCusdet(Customer cus);
//    
//    public abstract String updateCusdet(Customer cus);
//    
	
//	public String addCusdet(Customer cus);
//	
//	public String UpdateCusdet(Customer cus);
//	
//    public  String delCusdet(int cusId);
//    
//    public  Customer getCustomer(int cusID);
//    
//    public  List<Customer> getAllCustomer();

}
