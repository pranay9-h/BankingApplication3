package com.fis.bankapplication.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.TransactionDao;
import com.fis.bankapplication.model.Transaction;

@Service //annotate java classes that perform some service.
@Transactional //commit the actions we perform to the database from service

public class TransactionServiceImpl implements TransactionService{
	@Autowired //It injects dependency objects automatically
	TransactionDao trandao; 

	@Override // child class overrides base class
	public String addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		
		 trandao.save(transaction);
		 return "Transaction Details are saved Successfully";
	}

	@Override // child class overrides base class
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		List<Transaction> transactions = new ArrayList<Transaction>();
		 trandao.findAll().forEach(t-> transactions.add(t));;
		 return transactions;
	}

	@Override // child class overrides base class
	public List<Transaction> getAllTransactionsByAccno(long accNum) {
		// TODO Auto-generated method stub
		
		return trandao.getAllTransactionsByAccno(accNum);
	}

}
