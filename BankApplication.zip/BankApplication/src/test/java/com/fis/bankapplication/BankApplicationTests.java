package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.CustomerService;

@SpringBootTest
class BankApplicationTests {


@Autowired
CustomerService cser;
@Autowired
AccountService aser;

@Test
public void testAddCustomer() {
			Customer cus = new Customer(101,"Pranay",new Date(),1234567891,"pranay@gmail.com","Hyd","Pune","pranay","Developer");
			String msg=cser.addCusdet(cus);
			assertEquals("Customer Details are saved",msg);
}

@Test
public void testUpdateCustomer() {
			Customer cus = new Customer(101,"Pranay",new Date(),1223344551,"pranay@gmail.com","Hyd","Pune","pranay","Developer");
			String msg=cser.updateCusdet(cus);
			assertEquals("Customer Details Are Updated Successfully",msg);
}
@Test
public void testDeleteCustomer() {
			Customer cus = new Customer(101,"Pranay",new Date(),1223344551,"pranay@gmail.com","Hyd","Pune","pranay","Developer");
			String msg=cser.delCusdet(cus.getCustomerId());
			assertEquals("The Customer Details are deleted Successfully",msg);
}

@Test
public void testAddAccount() {
	//Customer cus = new Customer(111,"Pranay",new Date(),1223344551,"pranay@gmail.com","Hyd","Pune","pranay","Developer");
	Account acc=new Account(111,234000111,"Savings",new Date(),1000);
	String msg=aser.addAccdet(acc);
	assertEquals("Account Details are saved Successfully",msg);
}

@Test
public void testUpdateAccount() {
	//Customer cus = new Customer(101,"Pranay",new Date(),1223344551,"pranay@gmail.com","Hyd","Pune","pranay","Developer");
	Account acc=new Account(111,234000111,"Current",new Date(),1000);
	String msg=aser.updateAccdet(acc);
	assertEquals("Account Details are Updated Successfully",msg);
}

@Test
public void testDeleteAccount() {
	Account acc=new Account(111,234000111,"Current",new Date(),1000);
	String msg=aser.delAccdet(acc.getAccNum());
	assertEquals("Account Details Are Deleted Successfully",msg);
}
}
